/* my_car.h */
#ifndef INC_MY_CAR_H_
#define INC_MY_CAR_H_

#include "stm32l4xx_hal.h"

// Motor Commands
void Car_Stop(void);
void Car_Forward(void);
void Car_Backward(void);
void Car_Left(void);
void Car_Right(void);

// Ultrasonic
uint32_t Get_Distance(void);

#endif
