/* my_nrf24.h - CAR RX VERSION */
#ifndef INC_MY_NRF24_H_
#define INC_MY_NRF24_H_

#include "stm32l4xx_hal.h"

// Registers
#define NRF_CONFIG      0x00
#define NRF_RF_CH       0x05
#define NRF_RF_SETUP    0x06
#define NRF_STATUS      0x07
#define NRF_TX_ADDR     0x10
#define NRF_RX_ADDR_P1  0x0B
#define NRF_RX_PW_P1    0x12

// Commands
#define NRF_CMD_W_REGISTER    0x20
#define NRF_CMD_R_REGISTER    0x00
#define NRF_CMD_R_RX_PAYLOAD  0x61
#define NRF_CMD_FLUSH_RX      0xE2
#define NRF_CMD_NOP           0xFF

void NRF24_Init(SPI_HandleTypeDef *hspi);
void NRF24_RxMode(uint8_t *Address, uint8_t channel);
uint8_t NRF24_IsDataAvailable(void);
void NRF24_Receive(uint8_t *data);

#endif
