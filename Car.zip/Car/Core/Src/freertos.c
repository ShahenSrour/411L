/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : freertos.c
  * @brief          : Code for freertos applications
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "my_nrf24.h"
#include "my_car.h"
#include <string.h>
#include <stdio.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Variables */
extern SPI_HandleTypeDef hspi1;
extern TIM_HandleTypeDef htim6;
extern UART_HandleTypeDef huart2;

// Shared Variables
extern volatile char CarCommand[10];
extern volatile uint8_t SafetyOverride;
/* USER CODE END Variables */

/* Definitions for ControlTask */
osThreadId_t ControlTaskHandle;
const osThreadAttr_t ControlTask_attributes = {
  .name = "ControlTask",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityNormal,
};
/* Definitions for RadioTask */
osThreadId_t RadioTaskHandle;
const osThreadAttr_t RadioTask_attributes = {
  .name = "RadioTask",
  .stack_size = 256 * 4,
  .priority = (osPriority_t) osPriorityHigh,
};
/* Definitions for SafetyTask */
osThreadId_t SafetyTaskHandle;
const osThreadAttr_t SafetyTask_attributes = {
  .name = "SafetyTask",
  .stack_size = 256 * 4,
  .priority = (osPriority_t) osPriorityRealtime,
};

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN FunctionPrototypes */
/* USER CODE END FunctionPrototypes */

void StartDefaultTask(void *argument);
void StartTask02(void *argument);
void StartTask03(void *argument);

void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/**
  * @brief  FreeRTOS initialization
  * @param  None
  * @retval None
  */
void MX_FREERTOS_Init(void) {
  /* USER CODE BEGIN Init */
  /* USER CODE END Init */

  /* Create the thread(s) */
  /* creation of ControlTask */
  ControlTaskHandle = osThreadNew(StartDefaultTask, NULL, &ControlTask_attributes);

  /* creation of RadioTask */
  RadioTaskHandle = osThreadNew(StartTask02, NULL, &RadioTask_attributes);

  /* creation of SafetyTask */
  SafetyTaskHandle = osThreadNew(StartTask03, NULL, &SafetyTask_attributes);

  /* USER CODE BEGIN RTOS_THREADS */
  /* USER CODE END RTOS_THREADS */

}

/* USER CODE BEGIN Header_StartDefaultTask */
/**
  * @brief  Function implementing the ControlTask thread.
  */
/* USER CODE END Header_StartDefaultTask */
void StartDefaultTask(void *argument)
{
  /* USER CODE BEGIN StartDefaultTask */
  // CONTROL TASK (Moves Motors)
  char debugMsg[64];

  for(;;)
  {
    // Debug Print (Optional - Remove if it slows down response)
    sprintf(debugMsg, "Cmd: %s | Safe: %d\r\n", (char*)CarCommand, SafetyOverride);
    HAL_UART_Transmit(&huart2, (uint8_t*)debugMsg, strlen(debugMsg), 10);

    if (SafetyOverride == 1) {
        Car_Stop();
    }
    else {
        if (strcmp((char*)CarCommand, "FWD") == 0) Car_Forward();
        else if (strcmp((char*)CarCommand, "BACK") == 0) Car_Backward();
        else if (strcmp((char*)CarCommand, "LEFT") == 0) Car_Left();
        else if (strcmp((char*)CarCommand, "RIGHT") == 0) Car_Right();
        else Car_Stop();
    }
    osDelay(50);
  }
  /* USER CODE END StartDefaultTask */
}

/* USER CODE BEGIN Header_StartTask02 */
/**
* @brief Function implementing the RadioTask thread.
*/
/* USER CODE END Header_StartTask02 */
void StartTask02(void *argument)
{
  /* USER CODE BEGIN StartTask02 */
  // RADIO TASK (Receives Data)
  uint8_t RxData[32];
  for(;;)
  {
    if (NRF24_IsDataAvailable())
    {
       NRF24_Receive(RxData);
       strcpy((char*)CarCommand, (char*)RxData);
    }
    osDelay(20);
  }
  /* USER CODE END StartTask02 */
}

/* USER CODE BEGIN Header_StartTask03 */
/**
* @brief Function implementing the SafetyTask thread.
*/
/* USER CODE END Header_StartTask03 */
void StartTask03(void *argument)
{
  /* USER CODE BEGIN StartTask03 */
  // SAFETY TASK (Reads Ultrasonic)
  for(;;)
  {
    uint32_t dist = Get_Distance();

    if(dist > 0 && dist < 15) { // 15cm threshold
        SafetyOverride = 1;
    } else {
        SafetyOverride = 0;
    }
    osDelay(50);
  }
  /* USER CODE END StartTask03 */
}

/* Private application code --------------------------------------------------*/
/* USER CODE BEGIN Application */
/* USER CODE END Application */
