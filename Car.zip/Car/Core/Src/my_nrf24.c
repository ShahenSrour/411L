/* my_nrf24.c - CAR RX VERSION */
#include "my_nrf24.h"
#include "main.h"

SPI_HandleTypeDef *NRF_SPI;

#define NRF24_CSN_LOW()  HAL_GPIO_WritePin(NRF_CSN_GPIO_Port, NRF_CSN_Pin, GPIO_PIN_RESET)
#define NRF24_CSN_HIGH() HAL_GPIO_WritePin(NRF_CSN_GPIO_Port, NRF_CSN_Pin, GPIO_PIN_SET)
#define NRF24_CE_LOW()   HAL_GPIO_WritePin(NRF_CE_GPIO_Port, NRF_CE_Pin, GPIO_PIN_RESET)
#define NRF24_CE_HIGH()  HAL_GPIO_WritePin(NRF_CE_GPIO_Port, NRF_CE_Pin, GPIO_PIN_SET)

void NRF24_WriteReg(uint8_t Reg, uint8_t Data) {
    uint8_t buf[2];
    buf[0] = Reg | NRF_CMD_W_REGISTER;
    buf[1] = Data;
    NRF24_CSN_LOW();
    HAL_SPI_Transmit(NRF_SPI, buf, 2, 100);
    NRF24_CSN_HIGH();
}

void NRF24_WriteRegMulti(uint8_t Reg, uint8_t *data, int size) {
    uint8_t buf = Reg | NRF_CMD_W_REGISTER;
    NRF24_CSN_LOW();
    HAL_SPI_Transmit(NRF_SPI, &buf, 1, 100);
    HAL_SPI_Transmit(NRF_SPI, data, size, 1000);
    NRF24_CSN_HIGH();
}

void NRF24_Init(SPI_HandleTypeDef *hspi) {
    NRF_SPI = hspi;
    NRF24_CE_LOW();
    NRF24_CSN_HIGH();
}

void NRF24_RxMode(uint8_t *Address, uint8_t channel) {
    NRF24_CE_LOW();
    NRF24_WriteReg(NRF_RF_CH, channel);
    NRF24_WriteRegMulti(NRF_RX_ADDR_P1, Address, 5);
    NRF24_WriteReg(NRF_RX_PW_P1, 32); // Payload size 32

    // Power Up, CRC Enabled, RX Mode (PRIM_RX bit 0 = 1)
    NRF24_WriteReg(NRF_CONFIG, 0x0F);

    NRF24_CE_HIGH(); // Start Listening
}

uint8_t NRF24_IsDataAvailable(void) {
    uint8_t status;
    uint8_t cmd = NRF_CMD_NOP;
    NRF24_CSN_LOW();
    HAL_SPI_TransmitReceive(NRF_SPI, &cmd, &status, 1, 100);
    NRF24_CSN_HIGH();
    // Bit 6 in STATUS register is RX_DR (Data Ready)
    return (status & (1 << 6));
}

void NRF24_Receive(uint8_t *data) {
    uint8_t cmd = NRF_CMD_R_RX_PAYLOAD;
    NRF24_CSN_LOW();
    HAL_SPI_Transmit(NRF_SPI, &cmd, 1, 100);
    HAL_SPI_Receive(NRF_SPI, data, 32, 1000);
    NRF24_CSN_HIGH();

    // Clear the Data Ready flag
    NRF24_WriteReg(NRF_STATUS, (1 << 6));

    // Flush RX FIFO
    uint8_t flush = NRF_CMD_FLUSH_RX;
    NRF24_CSN_LOW();
    HAL_SPI_Transmit(NRF_SPI, &flush, 1, 100);
    NRF24_CSN_HIGH();
}
