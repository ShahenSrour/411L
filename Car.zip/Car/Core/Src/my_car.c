/* my_car.c */
#include "my_car.h"
#include "main.h"

extern TIM_HandleTypeDef htim1; // Left PWM
extern TIM_HandleTypeDef htim2; // Right PWM
extern TIM_HandleTypeDef htim6; // Microsecond timer

// --- Helper for Ultrasonic Delay ---
void delay_us(uint16_t us) {
    __HAL_TIM_SET_COUNTER(&htim6, 0);
    while (__HAL_TIM_GET_COUNTER(&htim6) < us);
}

// --- ULTRASONIC ---
uint32_t Get_Distance(void) {
    uint32_t pMillis, val1 = 0, val2 = 0;

    // 1. Send Trigger Pulse (10us)
    HAL_GPIO_WritePin(TRIG_GPIO_Port, TRIG_Pin, GPIO_PIN_SET);
    delay_us(10);
    HAL_GPIO_WritePin(TRIG_GPIO_Port, TRIG_Pin, GPIO_PIN_RESET);

    // 2. Wait for Echo High
    pMillis = HAL_GetTick();
    while (!(HAL_GPIO_ReadPin(ECHO_GPIO_Port, ECHO_Pin)) && pMillis + 10 >  HAL_GetTick());
    val1 = __HAL_TIM_GET_COUNTER(&htim6);

    // 3. Wait for Echo Low
    pMillis = HAL_GetTick();
    while ((HAL_GPIO_ReadPin(ECHO_GPIO_Port, ECHO_Pin)) && pMillis + 50 > HAL_GetTick());
    val2 = __HAL_TIM_GET_COUNTER(&htim6);

    // 4. Calculate Distance
    uint32_t distance = (val2 - val1) * 0.034 / 2;
    return distance;
}

// --- MOTORS ---
// Adjust "700" (70% speed). Range 0-999.
#define MOTOR_SPEED 700

void Car_Stop(void) {
    HAL_GPIO_WritePin(IN1_GPIO_Port, IN1_Pin, 0);
    HAL_GPIO_WritePin(IN2_GPIO_Port, IN2_Pin, 0);
    HAL_GPIO_WritePin(IN3_GPIO_Port, IN3_Pin, 0);
    HAL_GPIO_WritePin(IN4_GPIO_Port, IN4_Pin, 0);
    __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, 0);
    __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_3, 0);
}

void Car_Forward(void) {
    // Left Forward
    HAL_GPIO_WritePin(IN1_GPIO_Port, IN1_Pin, 1);
    HAL_GPIO_WritePin(IN2_GPIO_Port, IN2_Pin, 0);
    // Right Forward
    HAL_GPIO_WritePin(IN3_GPIO_Port, IN3_Pin, 1);
    HAL_GPIO_WritePin(IN4_GPIO_Port, IN4_Pin, 0);

    __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, MOTOR_SPEED);
    __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_3, MOTOR_SPEED);
}

void Car_Backward(void) {
    HAL_GPIO_WritePin(IN1_GPIO_Port, IN1_Pin, 0);
    HAL_GPIO_WritePin(IN2_GPIO_Port, IN2_Pin, 1);
    HAL_GPIO_WritePin(IN3_GPIO_Port, IN3_Pin, 0);
    HAL_GPIO_WritePin(IN4_GPIO_Port, IN4_Pin, 1);
    __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, MOTOR_SPEED);
    __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_3, MOTOR_SPEED);
}

void Car_Left(void) {
    // Left Back, Right Fwd
    HAL_GPIO_WritePin(IN1_GPIO_Port, IN1_Pin, 0);
    HAL_GPIO_WritePin(IN2_GPIO_Port, IN2_Pin, 1);
    HAL_GPIO_WritePin(IN3_GPIO_Port, IN3_Pin, 1);
    HAL_GPIO_WritePin(IN4_GPIO_Port, IN4_Pin, 0);
    __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, MOTOR_SPEED);
    __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_3, MOTOR_SPEED);
}

void Car_Right(void) {
    // Left Fwd, Right Back
    HAL_GPIO_WritePin(IN1_GPIO_Port, IN1_Pin, 1);
    HAL_GPIO_WritePin(IN2_GPIO_Port, IN2_Pin, 0);
    HAL_GPIO_WritePin(IN3_GPIO_Port, IN3_Pin, 0);
    HAL_GPIO_WritePin(IN4_GPIO_Port, IN4_Pin, 1);
    __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, MOTOR_SPEED);
    __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_3, MOTOR_SPEED);
}
