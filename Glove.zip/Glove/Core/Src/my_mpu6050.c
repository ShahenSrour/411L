/*
 * my_mpu6050.c
 * GLOVE PROJECT - MPU6050 DRIVER
 */

#include "my_mpu6050.h"
#include <string.h>

void MPU6050_Init(I2C_HandleTypeDef *hi2c) {
    uint8_t check;
    uint8_t Data;

    // 1. Check if device is connected
    if (HAL_I2C_IsDeviceReady(hi2c, MPU6050_ADDR, 1, 100) == HAL_OK) {
        // 2. Wake up the MPU6050 (It sleeps by default)
        // Write 0 to Power Management Register 1 (0x6B)
        Data = 0;
        HAL_I2C_Mem_Write(hi2c, MPU6050_ADDR, REG_PWR_MGMT_1, 1, &Data, 1, 100);
    }
}

void MPU6050_Read_Accel(I2C_HandleTypeDef *hi2c, MPU6050_t *DataStruct) {
    uint8_t Rec_Data[6];

    // Read 6 bytes starting from ACCEL_XOUT_H (0x3B)
    HAL_I2C_Mem_Read(hi2c, MPU6050_ADDR, REG_ACCEL_XOUT_H, 1, Rec_Data, 6, 100);

    // Combine High and Low bytes
    DataStruct->Accel_X_RAW = (int16_t)(Rec_Data[0] << 8 | Rec_Data[1]);
    DataStruct->Accel_Y_RAW = (int16_t)(Rec_Data[2] << 8 | Rec_Data[3]);
    DataStruct->Accel_Z_RAW = (int16_t)(Rec_Data[4] << 8 | Rec_Data[5]);

    /* * TILT LOGIC
     * Adjust these thresholds (3000) based on testing
     * X axis usually controls Forward/Back
     * Y axis usually controls Left/Right
     */

    int16_t threshold = 4000;

    // Reset
    strcpy(DataStruct->Orientation, "STOP");

    // Check X Axis (Forward / Backward)
    if (DataStruct->Accel_X_RAW > threshold) {
        strcpy(DataStruct->Orientation, "BACK");
    }
    else if (DataStruct->Accel_X_RAW < -threshold) {
        strcpy(DataStruct->Orientation, "FWD");
    }

    // Check Y Axis (Left / Right) -> Priority over FWD/BACK if tilt is extreme
    if (DataStruct->Accel_Y_RAW > threshold) {
        strcpy(DataStruct->Orientation, "RIGHT");
    }
    else if (DataStruct->Accel_Y_RAW < -threshold) {
        strcpy(DataStruct->Orientation, "LEFT");
    }
}
