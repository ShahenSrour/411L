/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : freertos.c
  * @brief          : GLOVE TRANSMITTER - FINAL LOGIC
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "my_mpu6050.h"
#include "my_nrf24.h"
#include <stdio.h>
#include <string.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Variables */
extern I2C_HandleTypeDef hi2c1;
extern SPI_HandleTypeDef hspi1;
extern UART_HandleTypeDef huart2;

// Shared Global Variable from main.c
extern MPU6050_t GloveState;
/* USER CODE END Variables */

/* Definitions for DisplayTask */
osThreadId_t DisplayTaskHandle;
const osThreadAttr_t DisplayTask_attributes = {
  .name = "DisplayTask",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityLow,
};
/* Definitions for SensorTask */
osThreadId_t SensorTaskHandle;
const osThreadAttr_t SensorTask_attributes = {
  .name = "SensorTask",
  .stack_size = 256 * 4,
  .priority = (osPriority_t) osPriorityNormal,
};
/* Definitions for RadioTask */
osThreadId_t RadioTaskHandle;
const osThreadAttr_t RadioTask_attributes = {
  .name = "RadioTask",
  .stack_size = 256 * 4,
  .priority = (osPriority_t) osPriorityAboveNormal,
};

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN FunctionPrototypes */
/* USER CODE END FunctionPrototypes */

void StartDefaultTask(void *argument);
void StartTask02(void *argument);
void StartTask03(void *argument);

void MX_FREERTOS_Init(void);

/**
  * @brief  FreeRTOS initialization
  * @param  None
  * @retval None
  */
void MX_FREERTOS_Init(void) {
  /* Create the thread(s) */
  DisplayTaskHandle = osThreadNew(StartDefaultTask, NULL, &DisplayTask_attributes);
  SensorTaskHandle = osThreadNew(StartTask02, NULL, &SensorTask_attributes);
  RadioTaskHandle = osThreadNew(StartTask03, NULL, &RadioTask_attributes);
}

/* USER CODE BEGIN Header_StartDefaultTask */
/**
  * @brief  Function implementing the DisplayTask thread.
  */
/* USER CODE END Header_StartDefaultTask */
void StartDefaultTask(void *argument)
{
  /* USER CODE BEGIN StartDefaultTask */
  // DISPLAY TASK (Optional Debugging)
  for(;;)
  {
    osDelay(1000);
  }
  /* USER CODE END StartDefaultTask */
}

/* USER CODE BEGIN Header_StartTask02 */
/**
  * @brief Function implementing the SensorTask thread.
  */
/* USER CODE END Header_StartTask02 */
void StartTask02(void *argument)
{
  /* USER CODE BEGIN StartTask02 */
  // SENSOR TASK (Reads MPU6050)
  char msg[32];

  for(;;)
  {
    // 1. Read Tilt Data
    MPU6050_Read_Accel(&hi2c1, &GloveState);

    // 2. Print to TeraTerm for verification
    sprintf(msg, "Tilt: %s\r\n", GloveState.Orientation);
    HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), 10);

    // 3. Update rate (20Hz)
    osDelay(50);
  }
  /* USER CODE END StartTask02 */
}

/* USER CODE BEGIN Header_StartTask03 */
/**
  * @brief Function implementing the RadioTask thread.
  */
/* USER CODE END Header_StartTask03 */
void StartTask03(void *argument)
{
  /* USER CODE BEGIN StartTask03 */
  // RADIO TASK (Sends Data)
  uint8_t MyTxData[32];

  for(;;)
  {
    // 1. Clear buffer
    memset(MyTxData, 0, 32);

    // 2. Prepare Payload (FWD, BACK, LEFT, RIGHT, STOP)
    strcpy((char*)MyTxData, GloveState.Orientation);

    // 3. Send
    NRF24_Transmit(MyTxData);

    // 4. Send Rate (10Hz)
    osDelay(100);
  }
  /* USER CODE END StartTask03 */
}

/* Private application code --------------------------------------------------*/
/* USER CODE BEGIN Application */
/* USER CODE END Application */
