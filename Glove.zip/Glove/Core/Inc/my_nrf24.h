/*
 * my_nrf24.h
 * GLOVE PROJECT - NRF24L01 DRIVER
 */

#ifndef INC_MY_NRF24_H_
#define INC_MY_NRF24_H_

#include "stm32l4xx_hal.h"

// NRF24L01 Registers
#define NRF_CONFIG      0x00
#define NRF_EN_AA       0x01
#define NRF_RF_CH       0x05
#define NRF_RF_SETUP    0x06
#define NRF_STATUS      0x07
#define NRF_TX_ADDR     0x10
#define NRF_RX_ADDR_P0  0x0A
#define NRF_FIFO_STATUS 0x17

// Commands
#define NRF_CMD_W_REGISTER    0x20
#define NRF_CMD_R_REGISTER    0x00
#define NRF_CMD_W_TX_PAYLOAD  0xA0
#define NRF_CMD_R_RX_PAYLOAD  0x61
#define NRF_CMD_FLUSH_TX      0xE1
#define NRF_CMD_FLUSH_RX      0xE2
#define NRF_CMD_NOP           0xFF

// Functions
void NRF24_Init(SPI_HandleTypeDef *hspi);
void NRF24_TxMode(uint8_t *Address, uint8_t channel);
uint8_t NRF24_Transmit(uint8_t *data);

// *** THIS WAS MISSING ***
void NRF24_ReadRegMulti(uint8_t Reg, uint8_t *data, int size);

#endif /* INC_MY_NRF24_H_ */
