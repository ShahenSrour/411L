/*
 * my_mpu6050.h
 * GLOVE PROJECT - MPU6050 DRIVER
 */

#ifndef INC_MY_MPU6050_H_
#define INC_MY_MPU6050_H_

#include "stm32l4xx_hal.h" // Change this if using a different series, but L4 is correct for you

// MPU6050 I2C Address (AD0 = GND)
#define MPU6050_ADDR 0xD0

// Registers
#define REG_PWR_MGMT_1 0x6B
#define REG_ACCEL_XOUT_H 0x3B

// Structure to hold our data
typedef struct {
    int16_t Accel_X_RAW;
    int16_t Accel_Y_RAW;
    int16_t Accel_Z_RAW;
    char Orientation[10]; // "STOP", "FWD", "BACK", "LEFT", "RIGHT"
} MPU6050_t;

// Functions
void MPU6050_Init(I2C_HandleTypeDef *hi2c);
void MPU6050_Read_Accel(I2C_HandleTypeDef *hi2c, MPU6050_t *DataStruct);

#endif /* INC_MY_MPU6050_H_ */
